# file write operation

#fobj = open('C:/new/output/customers.txt','w') 
#fobj = open(r'C:\new\output\customers.txt','w') # raw string
fobj = open('customers.txt','w')


fobj.write('python programming\n')
fobj.write('scale programming\n')


fobj.close()


### writing the numbers to file
fobj = open('numbers.txt','w')
for val in range(1,10):
    fobj.write(str(val) + "\n" )
fobj.close()