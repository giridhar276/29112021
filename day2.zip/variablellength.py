
## variable length parameters


def display(*data):
    for val in data:
        print(val)
    
    

#display(10,20,30,40,50,'hello',70,80,90,10)





def display(output):
    output.sort()
    print(output)


alist = [10,4,56,54]
display(alist)
print(alist)