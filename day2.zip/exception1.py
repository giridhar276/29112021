

import csv
import sys
try:
    fobj = open('realestate.csv','r')
    # convert file object to csv file object
    reader = csv.reader(fobj)
    
    for line in reader:
        print(line)
        
    fobj.close()
    output = 1 + "hello"
except FileNotFoundError as err:
    print(err)
    print(sys.exc_info()[0])
    print("File not found")
except TypeError as err:
    print(err)    
    print(sys.exc_info())
except (ValueError,IndexError) as err:
    print(err)
    print(sys.exc_info())
except Exception as err:
    print(err)
    print(sys.exc_info())
    
    