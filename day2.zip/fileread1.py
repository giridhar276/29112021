# read operation
# fobj can be called as
# file object or file cursor or handler or pointer
fobj = open('lang.txt','r')
header = fobj.readline()
for line in fobj:
    # remove whitespaces if any
    line = line.strip()
    #print(line)
    output = line.split(",")
    print(output[1])
fobj.close()


# using fobj.read()

fobj = open('lang.txt','r')
print(fobj.read())
fobj.close()

# using fobj.readlines()
fobj = open('lang.txt','r')
print(fobj.readlines())
fobj.close()



# using fobj.readlines()
fobj = open('lang.txt','r')
for line in fobj.readlines():
    print(line)
fobj.close()




