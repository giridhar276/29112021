


for val in range(0,2):
    for val2 in range(1,11):
        print('192','168',val,val2,sep='.')



password = input("Enter password: ")
if len(password) > 5 and len(password) < 12 and password.islower()  and password.islower() and password.islower() and password.islower():
    if password.find('@') == -1 and password.find('@') == -1 and password.find('@') == -1:
        print("invalid")
    else:
        print("valid")
else:
    print("invalid")
    
    
