


import alllib


print(alllib.block1())