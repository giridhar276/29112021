



# default  arguments

def display(a = 0,b = 0,c = 0):
    print(a,b,c)


display()
display(10)
display(10,20)
display(10,20,30)