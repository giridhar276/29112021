



name = input("Enter any name :")
print(name)