import csv


fobj = open('lang.txt','r')
# convert file object to csv file object
reader = csv.reader(fobj)

for line in reader:
    print(line)
    
fobj.close()
