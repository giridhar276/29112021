


def block1():
    return "this is block1"


def block2():
    return "this is block2"

