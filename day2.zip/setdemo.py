


aset = {10,20,30,10,20,20,30,30,30}
print(aset)

bset = {30,40,30,30,30,30,30,40,50}
print(bset)
print(len(bset))


print(aset.union(bset))
print(aset.intersection(bset))

print(aset.difference(bset))


aset.add(10)
print(aset)


aset.add(60)
print(aset)


alist = [10,30,40,10,10,10,10,20,20,20,20,20]
unique = list(set(alist))
print(unique)



