
# keyword arguments

def display(second,first):
    print(first,second)


display(first = 10,second = 20)



print(10,20,sep = " ",end = "\n\n")
print(10,20,end = "\n\n", sep = " ")


line = "a,b,c,d"
print(line.split())

line = "a,b,c,d"
print(line.split(","))

line = "a b c d"
print(line.split())