

## importing all the methods
import math

print(math.floor(43.4))
print(math.log(2))


# accessing with shortcut name
import math as m
print(m.ceil(45.4))


# importing required methods ONLY
from math import tan,log,cos
print(tan(2))
print(log(3))


# import all the methods directly
from math import *
print(tan(2))
print(log(3))
