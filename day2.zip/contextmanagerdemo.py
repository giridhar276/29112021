# context manager
# when the file pointer moves out of indentation
# the file gets closed automatically.
with open('lang.txt','r') as fobj:
    for line in fobj:
        # remove whitespaces if any
        line = line.strip()
        #print(line)
        print(line.split(","))
        
        
        
with open('output.txt','w') as fw:
    fw.write('python' + "\n")
    


    
    
    

