# lambda
# lambda is replacement of single liner function



# function
def add(a,b):
    return a + b

output = add(10,20)
print(output)



# lambda function
# functionname = lambda variables : expression
add = lambda x,y : x + y

output = add(10,20)
print(output)




def display(name):
    return name.upper()
    
print(display("python"))


display = lambda x : x.upper()
print(display("python"))




data = ["python","perl","unix"]
#  [ "python.org", "perl.org" ,"unix.org"]
newlist = []
for item in data:
    newlist.append(item + ".org")
print(newlist)
    

def addorg(x):
    return x + ".org"
data = ["python","perl","unix"]
print(list(map(addorg,data)))


#map(function,iterable)
addorg = lambda x : x + ".org"
data = ["python","perl","unix"]
print(list(map(addorg,data)))




data = ["python","perl","unix"]
print(list(map(lambda x : x + ".org",data)))




alist = [1,2,3,4,5,6]
# filter(function,iterable)
print(list(filter(lambda x : x%2 == 0 ,alist)))


alist = [1,2,3,4,5,6]
# filter(function,iterable)
print(list(filter(lambda x : x%2  ,alist)))


output = ['1','2','3']
print(list(map(lambda x : int(x) ,output)))














