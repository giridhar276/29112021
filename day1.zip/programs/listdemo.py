

alist = [56,34,67,98,12,23]

print("Elements are", alist)

# list slicing
print(alist[1])
print(alist[::-1])



alist[0] = 1000
print("Updated list :",alist)

# tuple
atup = (10,56,54)
#atup[0] = 56
#print("after replacing :", atup)

# typecasting
alist = list(atup)
alist[0] = 5666
atup = tuple(alist)
print("After changes" , atup)




alist = [56,34,246,54,5,78]

alist.append(90)

print("After apped :",alist)
alist.append(904)
print("After apped :",alist)

alist.extend([56,34,560,54,43])
print("After extending :",alist)


# list.insert(index position, value)
alist.insert(1,567)
print(alist)


print(alist.count(34))

# list.pop(index)
alist.pop(2)
print("After pop opreation :", alist)

# list.remove(value)   # not index
alist.remove(5)
print(alist)

if 500 in alist:
    alist.remove(500)
    print(alist)
else:
    print("value doesnt exist")
    
    
    
alist.sort()
print('After sorting ', alist)


alist.sort(reverse  = True)
print('After sorting ', alist)


alist.reverse()
print("after reversing" , alist)




print(alist)
print(type(alist))

print(isinstance(alist,tuple))




# for loop
for val in alist:
    print(val)









