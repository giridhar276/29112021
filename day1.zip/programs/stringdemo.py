
# single line comments
#val = 10
#print(val)

# multi line comment
'''
name = "python programming"
print(name)
'''

# name = "python programming"
# print(name)

name = "python programming"
print("I love", name)
print(1,2,3)
## string[start:stop:step]
# string slicing
print(name[0])
print(name[1])
print(name[0:5])
print(name[3:9])
print(name[:])
print(name[::])
print(name[0:17:2])
print(name[0:17:4])
print(name[1:16:2])
print(name[-1])
print(name[-2])
print(name[-4:-1])
print(name[::-1])
print(name[::-2])

name = "python programming"

print(name.upper())
print(name)
print(name.capitalize())
print(name.lower())
print(name.replace('python', 'scala'))

print(name.find('prog'))
print(name.find('asfa'))

print(name.split(" "))

aname = 'python,scala,hadoop,spark'
print(aname.split(","))

print(name.center(40))
print(name.center(40,"*"))

query = "select * from emp"

# template
name  = "I love {} and {}"

print(name.format('python','scala'))
print(name.format('C','CPP'))
print(name.format(1,2))

name = "python programming"
print(name.startswith('zpyt'))



if name.startswith('pyth'):
    print('its python programming')
    print("Still inside if cond")
    print("still inside if condition")
else:
    print('Its something else')
    print("Its something else")
    

if name.isupper():
    print("String is upper")
else:
    print("String is lower")

 


aname = '  python '
print(len(aname))

print(len(aname.strip()))
print(len(aname.lstrip()))
print(len(aname.rstrip()))


bname = 'python'
print(bname.strip('n'))




print(name)
for char in name:
    print(char)
    
for val in range(1,11):
    print(val)
    

for val in range(2,10,2):
    print(val)
    
    
for val in range(1,11,2):
    print(val)
    
    
for val in range(11,1,-2):
    print(val)
    
    



