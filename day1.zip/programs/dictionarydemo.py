


book = {"chap1":10 , "chap2":20 }

print(book)

print(book['chap1'])
# new key-value pair
book['chap3'] = 30

print(book)


print(book.keys())

print(book.values())

print(book.items())

#print(book["chap4"])
print(book.get('chap1'))
print(book.get('chap5'))



newbook = {"chap6":60,"chap7":70}

book.update(newbook)
print(book)

## adding book and newbook to final
final = { **book , **newbook }
print(final)





book = {"chap1":[10,"UK"] , "chap2":[20,"AUS"] }

print(book['chap1'])
 
 
 
 
 
book = {"chap1":10 , "chap2":20 ,"chap3":30 }

print(len(book))
## only keys
for  key in book.keys():
    print(key)

# only values
for value in book.values():
    print(value)
    
# reading both key and value    
for key,value in book.items():
    print(key,value)


# reading key and display value
for  key in book.keys():
    print(key)
    #print(book[key])
    print(book.get(key))









 