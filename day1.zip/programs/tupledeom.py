


atup = (45,459)

print(len(atup))



alist = [10,30,0,50]
print(len(alist))


name = "python"
print(len(name))



