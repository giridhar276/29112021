val = 10
print(isinstance(val,int))   # True
print(isinstance(val,float)) # false
print(isinstance(val,list))  # False


if isinstance(val,int):
    # your logic
    val  = val + 39
    print(val)


alist  = [10,20]
print(isinstance(alist,list))
print(isinstance(alist,tuple))


book = {"chap1":10 , "chap2":20 ,"chap3":30 }

print(isinstance(book,dict))  # True
print(isinstance(book,list))
print(isinstance(book,tuple))