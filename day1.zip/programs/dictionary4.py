
data = {
    "feeds": [
        {
            "id": 2140,
            "title": "gj",
            "description": "ghj",
            "location": "Hermannplatz 5-6, 10967 Berlin, Germany",
            "lng": 0,
            "lat": 0,
            "userId": 4051,
            "name": "manoj",
            "isdeleted": False,
            "profilePicture": "Images/9b291404-bc2e-4806-88c5-08d29e65a5ad.png",
            "videoUrl": ' ',
            "images": ' ',
            "mediatype": 0,
            "imagePaths": ' ',
            "feedsComment": ' ',
            "commentCount": 0,
            "multiMedia": [
                {
                    "id": 3240,
                    "name": "",
                    "description": ' ',
                    "url": "http://www.youtube.com/embed/mPhboJR0Llc",
                    "mediatype": 2,
                    "likeCount": 0,
                    "place": ' ',
                    "createAt": "0001-01-01T00:00:00"
                }
            ],
            "likeDislike": {
                "likes": 0,
                "dislikes": 0,
                "userAction": 2
            },
            "createdAt": "2020-01-02T13:32:16.7480006",
            "code": 0,
            "msg": ' '
        },
        {
            "id": 2139,
            "title": "dfg",
            "description": "df",
            "location": "443 N Rodeo Dr, Beverly Hills, CA 90210, USA",
            "lng": 0,
            "lat": 0,
            "userId": 4051,
            "name": "manoj",
            "isdeleted": False,
            "profilePicture": "Images/9b291404-bc2e-4806-88c5-08d29e65a5ad.png",
            "videoUrl": ' ',
            "images": ' ',
            "mediatype": 0,
            "imagePaths": ' ',
            "feedsComment": ' ',
            "commentCount": 2,
            "multiMedia": [
                {
                    "id": 3239,
                    "name": "",
                    "description": ' ',
                    "url": "http://www.youtube.com/embed/RtFcZ6Bwolw",
                    "mediatype": 2,
                    "likeCount": 0,
                    "place": ' ',
                    "createAt": "0001-01-01T00:00:00"
                }
            ],
            "likeDislike": {
                "likes": 0,
                "dislikes": 0,
                "userAction": 2
            },
            "createdAt": "2020-01-02T10:54:07.6092829",
            "code": 0,
            "msg": ' '
        },
        {
            "id": 2138,
            "title": "TEst Video",
            "description": "dflg sk mcn re  fg nerkzx xcvh ciu ",
            "location": "IFFCO Chowk Flyover, Heritage City, Sector 29, Gurugram, Haryana 122001, India",
            "lng": 0,
            "lat": 0,
            "userId": 4051,
            "name": "manoj",
            "isdeleted": False,
            "profilePicture": "Images/9b291404-bc2e-4806-88c5-08d29e65a5ad.png",
            "videoUrl": ' ',
            "images": ' ',
            "mediatype": 0,
            "imagePaths": ' ',
            "feedsComment": ' ',
            "commentCount": 0,
            "multiMedia": [
                {
                    "id": 3238,
                    "name": "",
                    "description": ' ',
                    "url": "http://www.youtube.com/embed/TUT2-FEPMdc",
                    "mediatype": 2,
                    "likeCount": 0,
                    "place": ' ',
                    "createAt": "0001-01-01T00:00:00"
                }
            ],
            "likeDislike": {
                "likes": 0,
                "dislikes": 0,
                "userAction": 2
            },
            "createdAt": "2020-01-02T10:53:36.8157098",
            "code": 0,
            "msg": ' '
        }
    ],
    "totalFeed": 125
}

print(data)